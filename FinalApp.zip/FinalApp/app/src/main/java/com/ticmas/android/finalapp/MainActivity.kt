package com.ticmas.android.finalapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.Observer
import androidx.activity.viewModels

class MainActivity : AppCompatActivity() {
    private val viewModel: ComparisonViewModel by viewModels()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        compareButton.setOnClickListener {
            val text1 = editText1.text.toString()
            val text2 = editText2.text.toString()
            viewModel.compareTexts(text1, text2)
        }

        viewModel.resultLiveData.observe(this, Observer { areEqual ->
            resultTextView.text = if (areEqual) "Los textos son iguales" else "Los textos son diferentes"
        })
    }
}